package com.alego.organizadorsoportes

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.documentfile.provider.DocumentFile

class SettingsActivity : Activity() {

    private val prefs by lazy { getSharedPreferences(Prefs.NAME, MODE_PRIVATE) }
    private lateinit var destLabel: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val title = TextView(this).apply {
            text = "Ajustes"
            textSize = 22f
            setPadding(0, 0, 0, 48)
        }

        destLabel = TextView(this).apply {
            text = "Carpeta destino actual:\n${currentDestLabel()}"
            setPadding(0, 16, 0, 24)
        }

        val chooseDestButton = Button(this).apply {
            text = "Elegir carpeta destino…"
            setOnClickListener { pickDestFolder() }
        }

        val resetDestButton = Button(this).apply {
            text = "Volver a la carpeta por defecto"
            setOnClickListener {
                prefs.edit().remove(Prefs.DEST_URI).apply()
                destLabel.text = "Carpeta destino actual:\n${currentDestLabel()}"
                Toast.makeText(this@SettingsActivity, "Listo", Toast.LENGTH_SHORT).show()
            }
        }

        val organizeByDateCheck = CheckBox(this).apply {
            text = "Organizar en subcarpetas por fecha"
            isChecked = prefs.getBoolean(Prefs.ORG_BY_DATE, true)
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean(Prefs.ORG_BY_DATE, checked).apply()
            }
        }

        val copyInsteadCheck = CheckBox(this).apply {
            text = "Copiar en vez de mover (dejar también el original en WhatsApp)"
            isChecked = prefs.getBoolean(Prefs.COPY_INSTEAD, false)
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean(Prefs.COPY_INSTEAD, checked).apply()
            }
        }

        val csvLogCheck = CheckBox(this).apply {
            text = "Guardar registro CSV (fecha, No. autorización, valor)"
            isChecked = prefs.getBoolean(Prefs.CSV_LOG, true)
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean(Prefs.CSV_LOG, checked).apply()
            }
        }

        val resetHistoryButton = Button(this).apply {
            text = "Olvidar historial de duplicados"
            setOnClickListener {
                prefs.edit()
                    .remove(Prefs.SEEN_KEYS)
                    .remove(Prefs.SKIP_FILES)
                    .apply()
                Toast.makeText(this@SettingsActivity, "Historial borrado", Toast.LENGTH_SHORT).show()
            }
        }

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 120, 48, 48)
            addView(title)
            addView(destLabel)
            addView(chooseDestButton)
            addView(resetDestButton)
            addView(spacer())
            addView(organizeByDateCheck)
            addView(copyInsteadCheck)
            addView(csvLogCheck)
            addView(spacer())
            addView(resetHistoryButton)
        }

        setContentView(ScrollView(this).apply { addView(content) })
    }

    private fun spacer(): TextView = TextView(this).apply {
        text = ""
        setPadding(0, 24, 0, 24)
    }

    private fun currentDestLabel(): String {
        val uriStr = prefs.getString(Prefs.DEST_URI, null) ?: return "SoportesDePago (por defecto, almacenamiento interno)"
        return try {
            DocumentFile.fromTreeUri(this, Uri.parse(uriStr))?.name ?: uriStr
        } catch (e: Exception) {
            "Carpeta elegida"
        }
    }

    private fun pickDestFolder() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE)
        startActivityForResult(intent, REQUEST_DEST_FOLDER)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_DEST_FOLDER && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            val flags = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            contentResolver.takePersistableUriPermission(uri, flags)
            prefs.edit().putString(Prefs.DEST_URI, uri.toString()).apply()
            destLabel.text = "Carpeta destino actual:\n${currentDestLabel()}"
        }
    }

    companion object {
        private const val REQUEST_DEST_FOLDER = 200
    }
}
