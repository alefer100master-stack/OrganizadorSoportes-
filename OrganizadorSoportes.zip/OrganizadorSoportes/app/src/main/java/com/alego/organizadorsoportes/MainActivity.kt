package com.alego.organizadorsoportes

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

/**
 * App personal para Alego.
 *
 * Al tocar el botón:
 *  1. Busca la carpeta "WhatsApp Images" en las rutas conocidas.
 *  2. A cada imagen nueva le hace OCR 100% en el propio teléfono (ML Kit,
 *     sin internet, sin nube, sin costo).
 *  3. Si el texto reconocido coincide con el formato de soporte de pago
 *     (Banco de Bogotá "Transacciones Realizadas"), corta el archivo y lo
 *     pega en /SoportesDePago/<fecha>/.
 *  4. Si no coincide, la recuerda para no volver a analizarla en el futuro.
 */
class MainActivity : Activity() {

    private lateinit var logView: TextView
    private val executor = Executors.newSingleThreadExecutor()
    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }
    private val prefs by lazy { getSharedPreferences("organizador_prefs", MODE_PRIVATE) }

    // Frases ancla del formato. Si el texto reconocido contiene al menos 2,
    // se considera un soporte de pago.
    private val keywords = listOf(
        "transacciones realizadas",
        "nro. autorizacion",
        "nro. autorización",
        "valor a pagar",
        "bancodebogota.com"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 120, 48, 48)
        }

        val button = Button(this).apply {
            text = "Analizar y organizar ahora"
            setOnClickListener { onAnalyzeClick() }
        }

        logView = TextView(this).apply {
            text = "Toca el botón para buscar soportes de pago nuevos en WhatsApp Images."
            gravity = Gravity.START
            setPadding(0, 48, 0, 0)
        }

        val scroll = ScrollView(this).apply { addView(logView) }

        root.addView(button)
        root.addView(
            scroll,
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
        )

        setContentView(root)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == PERMISSION_REQUEST_CODE &&
            grantResults.isNotEmpty() &&
            grantResults[0] == PackageManager.PERMISSION_GRANTED
        ) {
            onAnalyzeClick()
        }
    }

    private fun log(msg: String) {
        runOnUiThread { logView.text = msg + "\n\n" + logView.text }
    }

    private fun onAnalyzeClick() {
        if (!hasAllFilesAccess()) {
            requestAllFilesAccess()
            return
        }
        log("Analizando… esto puede tardar unos segundos.")
        executor.execute { scanAndOrganize() }
    }

    private fun hasAllFilesAccess(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            Environment.isExternalStorageManager()
        } else {
            ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) ==
                PackageManager.PERMISSION_GRANTED
        }
    }

    private fun requestAllFilesAccess() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            log("Activa \"Acceso a todos los archivos\" para esta app en la pantalla que se abrirá, y luego vuelve a tocar el botón.")
            try {
                val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION)
                intent.data = Uri.parse("package:$packageName")
                startActivity(intent)
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
            }
        } else {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(
                    Manifest.permission.READ_EXTERNAL_STORAGE,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE
                ),
                PERMISSION_REQUEST_CODE
            )
        }
    }

    private fun candidateWhatsAppFolders(): List<File> {
        val root = Environment.getExternalStorageDirectory()
        return listOf(
            File(root, "Android/media/com.whatsapp/WhatsApp/Media/WhatsApp Images"),
            File(root, "WhatsApp/Media/WhatsApp Images")
        ).filter { it.exists() && it.isDirectory }
    }

    private fun scanAndOrganize() {
        val folders = candidateWhatsAppFolders()
        if (folders.isEmpty()) {
            log("No encontré la carpeta \"WhatsApp Images\" en las rutas conocidas de este teléfono.")
            return
        }

        val skip = prefs.getStringSet(PREF_SKIP, emptySet()) ?: emptySet()
        val newSkip = skip.toMutableSet()
        var moved = 0
        var checked = 0

        for (folder in folders) {
            val files = folder.listFiles { f ->
                f.isFile && (
                    f.name.endsWith(".jpg", true) ||
                        f.name.endsWith(".jpeg", true) ||
                        f.name.endsWith(".png", true)
                    )
            } ?: continue

            for (file in files) {
                val key = file.absolutePath + "_" + file.lastModified()
                if (newSkip.contains(key)) continue
                checked++

                val text = try {
                    recognizeText(file)
                } catch (e: Exception) {
                    ""
                }

                val lower = text.lowercase(Locale.getDefault())
                val matches = keywords.count { lower.contains(it) }

                if (matches >= 2) {
                    val dateFolderName = extractFecha(text)
                        ?: SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date(file.lastModified()))
                    val destDir = File(
                        Environment.getExternalStorageDirectory(),
                        "SoportesDePago/$dateFolderName"
                    )
                    if (!destDir.exists()) destDir.mkdirs()
                    val destFile = File(destDir, file.name)

                    val ok = try {
                        file.copyTo(destFile, overwrite = true)
                        file.delete()
                    } catch (e: Exception) {
                        false
                    }

                    if (ok) {
                        moved++
                        log("✔ Movido a SoportesDePago/$dateFolderName/${file.name}")
                    } else {
                        log("✘ No pude mover ${file.name}")
                        newSkip.add(key)
                    }
                } else {
                    newSkip.add(key)
                }
            }
        }

        prefs.edit().putStringSet(PREF_SKIP, newSkip).apply()
        log("Listo. Revisadas: $checked · Movidas: $moved")
    }

    private fun extractFecha(text: String): String? {
        val regex = Regex(
            "Fecha de Emisi[oó]n\\s*[:\\-]?\\s*(\\d{4}/\\d{2}/\\d{2})",
            RegexOption.IGNORE_CASE
        )
        val match = regex.find(text) ?: return null
        return match.groupValues[1].replace("/", "-")
    }

    /** Decodifica la imagen con una resolución razonable para OCR sin agotar memoria. */
    private fun recognizeText(file: File): String {
        val boundsOpts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.absolutePath, boundsOpts)

        var sample = 1
        val targetWidth = 1600
        while (boundsOpts.outWidth > 0 && boundsOpts.outWidth / (sample * 2) >= targetWidth) {
            sample *= 2
        }

        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val bitmap = BitmapFactory.decodeFile(file.absolutePath, opts) ?: return ""

        val image = InputImage.fromBitmap(bitmap, 0)
        val result = Tasks.await(recognizer.process(image))
        return result.text
    }

    companion object {
        private const val PERMISSION_REQUEST_CODE = 100
        private const val PREF_SKIP = "skip_files"
    }
}
