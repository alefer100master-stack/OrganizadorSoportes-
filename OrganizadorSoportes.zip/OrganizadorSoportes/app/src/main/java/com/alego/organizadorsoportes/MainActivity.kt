package com.alego.organizadorsoportes

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.documentfile.provider.DocumentFile
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.io.File
import java.io.FileWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import java.util.zip.CRC32

/**
 * App personal "Soportes de Pago" para Alego.
 *
 * Al tocar el botón:
 *  1. Busca la carpeta "WhatsApp Images" en las rutas conocidas.
 *  2. A cada imagen nueva le hace OCR 100% en el propio teléfono (ML Kit,
 *     sin internet, sin nube, sin costo).
 *  3. Si el texto reconocido coincide con el formato de soporte de pago
 *     (Banco de Bogotá "Transacciones Realizadas"), y NO es un duplicado
 *     ya archivado antes (por Nro. de Autorización), corta o copia el
 *     archivo a la carpeta destino configurada.
 *  4. Si no coincide, la recuerda para no volver a analizarla en el futuro.
 */
class MainActivity : Activity() {

    private lateinit var logView: TextView
    private val executor = Executors.newSingleThreadExecutor()
    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }
    private val prefs by lazy { getSharedPreferences(Prefs.NAME, MODE_PRIVATE) }

    // Frases ancla del formato. Si el texto reconocido contiene al menos 2,
    // se considera un soporte de pago.
    private val keywords = listOf(
        "transacciones realizadas",
        "nro. autorizacion",
        "nro. autorización",
        "valor a pagar",
        "bancodebogota.com"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 120, 48, 48)
        }

        val buttonRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }

        val analyzeButton = Button(this).apply {
            text = "Analizar y organizar ahora"
            setOnClickListener { onAnalyzeClick() }
        }

        val settingsButton = Button(this).apply {
            text = "Ajustes"
            setOnClickListener {
                startActivity(Intent(this@MainActivity, SettingsActivity::class.java))
            }
        }

        buttonRow.addView(
            analyzeButton,
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        )
        buttonRow.addView(settingsButton)

        logView = TextView(this).apply {
            text = "Toca el botón para buscar soportes de pago nuevos en WhatsApp Images."
            gravity = Gravity.START
            setPadding(0, 48, 0, 0)
        }

        val scroll = ScrollView(this).apply { addView(logView) }

        root.addView(buttonRow)
        root.addView(
            scroll,
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
        )

        setContentView(root)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == PERMISSION_REQUEST_CODE &&
            grantResults.isNotEmpty() &&
            grantResults[0] == PackageManager.PERMISSION_GRANTED
        ) {
            onAnalyzeClick()
        }
    }

    private fun log(msg: String) {
        runOnUiThread { logView.text = msg + "\n\n" + logView.text }
    }

    private fun onAnalyzeClick() {
        if (!hasAllFilesAccess()) {
            requestAllFilesAccess()
            return
        }
        log("Analizando… esto puede tardar unos segundos.")
        executor.execute { scanAndOrganize() }
    }

    private fun hasAllFilesAccess(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            Environment.isExternalStorageManager()
        } else {
            ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) ==
                PackageManager.PERMISSION_GRANTED
        }
    }

    private fun requestAllFilesAccess() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            log("Activa \"Acceso a todos los archivos\" para esta app en la pantalla que se abrirá, y luego vuelve a tocar el botón.")
            try {
                val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION)
                intent.data = Uri.parse("package:$packageName")
                startActivity(intent)
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
            }
        } else {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(
                    Manifest.permission.READ_EXTERNAL_STORAGE,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE
                ),
                PERMISSION_REQUEST_CODE
            )
        }
    }

    private fun candidateWhatsAppFolders(): List<File> {
        val root = Environment.getExternalStorageDirectory()
        return listOf(
            File(root, "Android/media/com.whatsapp/WhatsApp/Media/WhatsApp Images"),
            File(root, "WhatsApp/Media/WhatsApp Images")
        ).filter { it.exists() && it.isDirectory }
    }

    private fun scanAndOrganize() {
        val folders = candidateWhatsAppFolders()
        if (folders.isEmpty()) {
            log("No encontré la carpeta \"WhatsApp Images\" en las rutas conocidas de este teléfono.")
            return
        }

        val organizeByDate = prefs.getBoolean(Prefs.ORG_BY_DATE, true)
        val copyInstead = prefs.getBoolean(Prefs.COPY_INSTEAD, false)
        val csvLogEnabled = prefs.getBoolean(Prefs.CSV_LOG, true)

        val skip = prefs.getStringSet(Prefs.SKIP_FILES, emptySet()) ?: emptySet()
        val newSkip = skip.toMutableSet()
        val seen = prefs.getStringSet(Prefs.SEEN_KEYS, emptySet()) ?: emptySet()
        val newSeen = seen.toMutableSet()

        var moved = 0
        var duplicates = 0
        var checked = 0

        for (folder in folders) {
            val files = folder.listFiles { f ->
                f.isFile && (
                    f.name.endsWith(".jpg", true) ||
                        f.name.endsWith(".jpeg", true) ||
                        f.name.endsWith(".png", true)
                    )
            } ?: continue

            for (file in files) {
                val skipKey = file.absolutePath + "_" + file.lastModified()
                if (newSkip.contains(skipKey)) continue
                checked++

                val text = try {
                    recognizeText(file)
                } catch (e: Exception) {
                    ""
                }

                val lower = text.lowercase(Locale.getDefault())
                val matches = keywords.count { lower.contains(it) }

                if (matches < 2) {
                    newSkip.add(skipKey)
                    continue
                }

                val authNumber = extractAuthNumber(text)
                val dedupKey = authNumber?.let { "auth:$it" } ?: "hash:${computeFileHash(file)}"

                if (newSeen.contains(dedupKey)) {
                    duplicates++
                    newSkip.add(skipKey)
                    log("⏭ Duplicado (ya archivado antes): ${file.name}")
                    continue
                }

                val dateFolder = if (organizeByDate) {
                    extractFecha(text)
                        ?: SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date(file.lastModified()))
                } else null

                val ok = fileToDestination(file, dateFolder)

                if (ok) {
                    if (!copyInstead) file.delete()
                    moved++
                    newSeen.add(dedupKey)
                    if (csvLogEnabled) {
                        appendCsvLog(file.name, dateFolder, authNumber, extractValor(text))
                    }
                    val destino = dateFolder?.let { "$it/" } ?: ""
                    log("✔ ${if (copyInstead) "Copiado" else "Movido"} a $destino${file.name}")
                } else {
                    log("✘ No pude copiar ${file.name}")
                }
                newSkip.add(skipKey)
            }
        }

        prefs.edit()
            .putStringSet(Prefs.SKIP_FILES, newSkip)
            .putStringSet(Prefs.SEEN_KEYS, newSeen)
            .apply()

        log("Listo. Revisadas: $checked · Archivadas: $moved · Duplicadas: $duplicates")
    }

    // ---------- Destino del archivo ----------

    private fun fileToDestination(file: File, dateFolder: String?): Boolean {
        val treeUriStr = prefs.getString(Prefs.DEST_URI, null)
        return if (treeUriStr != null) {
            copyToDocumentTree(file, Uri.parse(treeUriStr), dateFolder)
        } else {
            copyToDefaultFolder(file, dateFolder)
        }
    }

    private fun copyToDefaultFolder(file: File, dateFolder: String?): Boolean {
        val base = File(Environment.getExternalStorageDirectory(), "SoportesDePago")
        val destDir = if (dateFolder != null) File(base, dateFolder) else base
        if (!destDir.exists()) destDir.mkdirs()
        val destFile = File(destDir, file.name)
        return try {
            file.copyTo(destFile, overwrite = true)
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun copyToDocumentTree(file: File, treeUri: Uri, dateFolder: String?): Boolean {
        return try {
            val root = DocumentFile.fromTreeUri(this, treeUri) ?: return false
            val targetDir = if (dateFolder != null) {
                root.findFile(dateFolder)?.takeIf { it.isDirectory }
                    ?: root.createDirectory(dateFolder) ?: return false
            } else root

            targetDir.findFile(file.name)?.delete()
            val newDoc = targetDir.createFile(mimeTypeFor(file.name), file.name) ?: return false

            contentResolver.openOutputStream(newDoc.uri)?.use { out ->
                file.inputStream().use { input -> input.copyTo(out) }
            } ?: return false
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun mimeTypeFor(fileName: String): String = when {
        fileName.endsWith(".png", true) -> "image/png"
        fileName.endsWith(".jpg", true) || fileName.endsWith(".jpeg", true) -> "image/jpeg"
        else -> "application/octet-stream"
    }

    // ---------- Registro CSV (siempre en almacenamiento interno, para poder anexarlo fácil) ----------

    private fun appendCsvLog(fileName: String, dateFolder: String?, authNumber: String?, valor: String?) {
        try {
            val logDir = File(Environment.getExternalStorageDirectory(), "SoportesDePago")
            if (!logDir.exists()) logDir.mkdirs()
            val logFile = File(logDir, "registro.csv")
            val isNew = !logFile.exists()
            FileWriter(logFile, true).use { writer ->
                if (isNew) writer.append("fecha_procesado,carpeta,archivo,nro_autorizacion,valor_a_pagar\n")
                val now = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date())
                writer.append("\"$now\",\"${dateFolder ?: ""}\",\"$fileName\",\"${authNumber ?: ""}\",\"${valor ?: ""}\"\n")
            }
        } catch (e: Exception) {
            // No bloquear el flujo principal si falla el registro.
        }
    }

    // ---------- Extracción de texto ----------

    private fun extractFecha(text: String): String? {
        val regex = Regex(
            "Fecha de Emisi[oó]n\\s*[:\\-]?\\s*(\\d{4}/\\d{2}/\\d{2})",
            RegexOption.IGNORE_CASE
        )
        return regex.find(text)?.groupValues?.get(1)?.replace("/", "-")
    }

    private fun extractAuthNumber(text: String): String? {
        val regex = Regex(
            "Nro\\.?\\s*Autorizaci[oó]n[^0-9]{0,10}(\\d{4,})",
            RegexOption.IGNORE_CASE
        )
        return regex.find(text)?.groupValues?.get(1)
    }

    private fun extractValor(text: String): String? {
        val regex = Regex(
            "Valor a Pagar[^0-9]{0,10}([\\d.,]+)",
            RegexOption.IGNORE_CASE
        )
        return regex.find(text)?.groupValues?.get(1)
    }

    private fun computeFileHash(file: File): String {
        return try {
            val crc = CRC32()
            file.inputStream().use { input ->
                val buffer = ByteArray(8192)
                var read: Int
                while (input.read(buffer).also { read = it } != -1) {
                    crc.update(buffer, 0, read)
                }
            }
            crc.value.toString(16)
        } catch (e: Exception) {
            file.name
        }
    }

    /** Decodifica la imagen con una resolución razonable para OCR sin agotar memoria. */
    private fun recognizeText(file: File): String {
        val boundsOpts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.absolutePath, boundsOpts)

        var sample = 1
        val targetWidth = 1600
        while (boundsOpts.outWidth > 0 && boundsOpts.outWidth / (sample * 2) >= targetWidth) {
            sample *= 2
        }

        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val bitmap = BitmapFactory.decodeFile(file.absolutePath, opts) ?: return ""

        val image = InputImage.fromBitmap(bitmap, 0)
        val result = Tasks.await(recognizer.process(image))
        return result.text
    }

    companion object {
        private const val PERMISSION_REQUEST_CODE = 100
    }
}
