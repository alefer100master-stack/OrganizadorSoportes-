package com.alego.organizadorsoportes

/** Nombres de las preferencias guardadas, compartidos entre MainActivity y SettingsActivity. */
object Prefs {
    const val NAME = "organizador_prefs"

    // Carpeta destino elegida por el usuario (SAF tree Uri). Si es null, se usa la carpeta
    // por defecto SoportesDePago en el almacenamiento interno.
    const val DEST_URI = "dest_tree_uri"

    // true = crea una subcarpeta por fecha dentro del destino. false = todo en una sola carpeta.
    const val ORG_BY_DATE = "organize_by_date"

    // true = copia el archivo y lo deja también en WhatsApp. false = lo corta (comportamiento original).
    const val COPY_INSTEAD = "copy_instead_of_move"

    // true = además de mover el archivo, agrega una fila a SoportesDePago/registro.csv
    const val CSV_LOG = "save_csv_log"

    // Claves ya archivadas (Nro. de Autorización, o hash del archivo si no se pudo leer el número)
    // para no volver a copiar un soporte que ya fue procesado antes, aunque WhatsApp lo reenvíe
    // con otro nombre de archivo.
    const val SEEN_KEYS = "seen_keys"

    // Archivos ya revisados que NO son soportes de pago, para no repetir el OCR en cada toque.
    const val SKIP_FILES = "skip_files"
}
